package org.quiltmc.users.duckteam.ducktech.machines.nogui;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.List;

public class DuckTechMachinesCrusherEntity extends BlockEntity {
    private int cooldown = 0;

    public DuckTechMachinesCrusherEntity(BlockPos pos, BlockState state) {
        super(DuckTechMachinesCrusherEntities.CRUSHER.get(), pos, state);
    }

    public static void tick(Level level, BlockPos pos, BlockState state, DuckTechMachinesCrusherEntity entity) {
        if (level.isClientSide) return;

        entity.cooldown++;
        if (entity.cooldown >= 20) {
            entity.cooldown = 0;
            entity.processItems();
        }
    }

    private void processItems() {
        BlockPos abovePos = worldPosition.above();
        AABB detectionArea = new AABB(
                abovePos.getX(), abovePos.getY(), abovePos.getZ(),
                abovePos.getX() + 1, abovePos.getY() + 0.5, abovePos.getZ() + 1
        );

        List<ItemEntity> itemsAbove = level.getEntitiesOfClass(
                ItemEntity.class, detectionArea
        );

        ItemEntity ironOreEntity = null;
        ItemEntity essenceEntity = null;

        for (ItemEntity itemEntity : itemsAbove) {
            ItemStack stack = itemEntity.getItem();
            if (stack.getItem() == Items.IRON_ORE && ironOreEntity == null) {
                ironOreEntity = itemEntity;
            } else if (stack.getItem() == ForgeRegistries.ITEMS.getValue(
                    new ResourceLocation("ducktech", "crushed_essence"))
                    && essenceEntity == null) {
                essenceEntity = itemEntity;
            }
        }

        // 3. 如果找到两种物品
        if (ironOreEntity != null && essenceEntity != null) {
            // 移除物品（各1个）
            consumeItem(ironOreEntity);
            consumeItem(essenceEntity);

            // 4. 在正下方生成铁粉
            BlockPos belowPos = worldPosition.below();
            Item dustIron = ForgeRegistries.ITEMS.getValue(
                    new ResourceLocation("ducktech", "iron_dust")
            );

            if (dustIron != null) {
                ItemEntity dustEntity = new ItemEntity(
                        level,
                        belowPos.getX() + 0.5,
                        belowPos.getY() + 1.0, // 在下方方块的上表面
                        belowPos.getZ() + 0.5,
                        new ItemStack(dustIron, 2)
                );
                level.addFreshEntity(dustEntity);
            }
        }
    }

    private void consumeItem(ItemEntity itemEntity) {
        ItemStack stack = itemEntity.getItem();
        stack.shrink(1);

        if (stack.isEmpty()) {
            itemEntity.discard();
        } else {
            itemEntity.setItem(stack);
        }
    }
}