package org.quiltmc.users.duckteam.ducktech.machines.nogui;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import org.quiltmc.users.duckteam.ducktech.DuckTech;

import java.util.ArrayList;
import java.util.List;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
public class DuckTechMachinesCrusherEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, DuckTech.MODID);

    public static final RegistryObject<BlockEntityType<DuckTechMachinesCrusherNewEntity>> CRUSHER =
            BLOCK_ENTITIES.register("crusher", () ->
                    BlockEntityType.Builder.of(
                            DuckTechMachinesCrusherNewEntity::new,
                            DuckTechMachinesCrusher.CRUSHER.get()
                    ).build(null));

    @SubscribeEvent
    public static void onServerTick(TickEvent.LevelTickEvent event) {
        if (event.phase == TickEvent.Phase.END && event.level instanceof ServerLevel serverLevel) {
            List<BlockEntity> blockEntities = new ArrayList<>();

            for (int x = -300; x <= 300; x += 16) {
                for (int z = -300; z <= 300; z += 16) {
                    if (serverLevel.hasChunk(x >> 4, z >> 4)) {
                        var chunk = serverLevel.getChunk(x >> 4, z >> 4);

                        chunk.getBlockEntities().forEach((pos, blockEntity) -> {
                            if (blockEntity instanceof DuckTechMachinesCrusherNewEntity crusher) {
                                DuckTechMachinesCrusherNewEntity.serverTick(
                                        serverLevel,
                                        pos,
                                        blockEntity.getBlockState(),
                                        crusher
                                );
                            }
                        });
                    }
                }
            }
        }
    }
}