package org.quiltmc.users.duckteam.ducktech.machines.nogui;

import net.minecraft.core.BlockPos;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import org.quiltmc.users.duckteam.ducktech.DuckTech;
import org.quiltmc.users.duckteam.ducktech.items.DuckTechNewItemsLoader;

import java.util.function.Supplier;

public class DuckTechMachinesCrusher {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, DuckTech.MODID);

    private static final BlockBehaviour.Properties CRUSHER_PROPERTIES =
            BlockBehaviour.Properties.of()
                    .mapColor(MapColor.METAL)
                    .sound(SoundType.METAL)
                    .strength(5.0F, 6.0F)
                    .requiresCorrectToolForDrops();

    public static final RegistryObject<Block> CRUSHER = registerBlock("crusher",
            () -> new Block(CRUSHER_PROPERTIES));

    private static <T extends Block> RegistryObject<T> registerBlock(String name, Supplier<T> block) {
        RegistryObject<T> toReturn = BLOCKS.register(name, block);
        registerBlockItem(name, toReturn);
        return toReturn;
    }

    private static <T extends Block> void registerBlockItem(String name, RegistryObject<T> block) {
        DuckTechNewItemsLoader.ITEMS.register(name, () -> new BlockItem(block.get(),
                new Item.Properties()));
    }

    public static void register(IEventBus eventBus){
        BLOCKS.register(eventBus);
    }
    //public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        //return level.isClientSide ? null : ($0, $1, $2, blockEntity) -> ((DuckTechMachinesCrusherEntity) blockEntity).tick(level, $1, $2, (DuckTechMachinesCrusherEntity) blockEntity);
    //}
    //@Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return DuckTechMachinesCrusherEntities.CRUSHER.get().create(pos, state);
    }
}
