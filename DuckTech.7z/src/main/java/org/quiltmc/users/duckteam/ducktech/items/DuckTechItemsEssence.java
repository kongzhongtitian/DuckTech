package org.quiltmc.users.duckteam.ducktech.items;

import net.minecraft.world.item.Item;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class DuckTechItemsEssence {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, org.quiltmc.users.duckteam.ducktech.DuckTech.MODID);

    public static final RegistryObject<Item> CRUSHED_ESSENCE = registerIngot("crushed_essence");

    private static RegistryObject<Item> registerIngot(String name) {
        return ITEMS.register(name, () -> new Item(new Item.Properties()));
    }

    public static void register(IEventBus eventBus) {
        ITEMS.register(eventBus);
    }
}
