package org.quiltmc.users.duckteam.ducktech.machines.nogui;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import org.quiltmc.users.duckteam.ducktech.items.DuckTechItemsDust;
import org.quiltmc.users.duckteam.ducktech.items.DuckTechItemsEssence;

import java.util.List;

public class DuckTechMachinesCrusherNewEntity extends BlockEntity {
    private int processTimer;

    public DuckTechMachinesCrusherNewEntity(BlockPos pos, BlockState state) {
        super(DuckTechMachinesCrusherEntities.CRUSHER.get(), pos, state);
    }

    public static <T extends BlockEntity> void serverTick(Level level, BlockPos pos, BlockState state, T be) {
        if (be instanceof DuckTechMachinesCrusherNewEntity crusher) {
            crusher.tick();
        }
    }

    private void tick() {
        if (level == null || level.isClientSide) return;

        if (hasValidItemsOnTop()) {
            if (processTimer < 20) { // 20 ticks = 1秒
                processTimer++;
            } else {
                processItems();
                processTimer = 0;
            }
        } else {
            processTimer = 0;
        }
    }

    private boolean hasValidItemsOnTop() {
        AABB detectionArea = new AABB(
                worldPosition.getX() + 0.3,  // 缩小范围以避免边缘误判
                worldPosition.getY() + 1.0,  // 方块顶部上方
                worldPosition.getZ() + 0.3,
                worldPosition.getX() + 0.7,
                worldPosition.getY() + 1.5,  // 允许一定高度
                worldPosition.getZ() + 0.7
        );

        List<ItemEntity> items = level.getEntitiesOfClass(
                ItemEntity.class,
                detectionArea,
                entity -> !entity.isRemoved()
        );

        boolean hasIronOre = false;
        boolean hasEssence = false;
        for (ItemEntity item : items) {
            ItemStack stack = item.getItem();
            if (stack.getItem() == Items.IRON_ORE) hasIronOre = true;
            if (stack.getItem() == DuckTechItemsEssence.CRUSHED_ESSENCE.get()) hasEssence = true;
        }

        return hasIronOre && hasEssence;
    }

    private void processItems() {
        AABB detectionArea = new AABB(
                worldPosition.getX() + 0.3,
                worldPosition.getY() + 1.0,
                worldPosition.getZ() + 0.3,
                worldPosition.getX() + 0.7,
                worldPosition.getY() + 1.5,
                worldPosition.getZ() + 0.7
        );

        List<ItemEntity> items = level.getEntitiesOfClass(
                ItemEntity.class,
                detectionArea,
                entity -> !entity.isRemoved()
        );

        for (ItemEntity item : items) {
            ItemStack stack = item.getItem();
            if (stack.getItem() == Items.IRON_ORE || stack.getItem() == DuckTechItemsEssence.CRUSHED_ESSENCE.get()) {
                stack.shrink(1);
                if (stack.isEmpty()) {
                    item.discard();
                }
            }
        }

        // 在下方生成2个铁粉
        BlockPos outputPos = worldPosition.below();
        ItemStack output = new ItemStack(DuckTechItemsDust.IRON_DUST.get(), 2);
        level.addFreshEntity(new ItemEntity(
                level,
                outputPos.getX() + 0.5,
                outputPos.getY() + 0.5,
                outputPos.getZ() + 0.5,
                output
        ));
    }
}