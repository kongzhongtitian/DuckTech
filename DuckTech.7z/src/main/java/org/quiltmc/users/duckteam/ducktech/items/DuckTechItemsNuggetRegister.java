package org.quiltmc.users.duckteam.ducktech.items;

import net.minecraft.world.item.Item;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class DuckTechItemsNuggetRegister {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, org.quiltmc.users.duckteam.ducktech.DuckTech.MODID);

    public static final RegistryObject<Item> LEAD_NUGGET = registerNugget("lead_nugget");
    public static final RegistryObject<Item> ALUMINUM_NUGGET = registerNugget("aluminum_nugget");
    public static final RegistryObject<Item> TIN_NUGGET = registerNugget("tin_nugget");
    public static final RegistryObject<Item> SILVER_NUGGET = registerNugget("silver_nugget");

    private static RegistryObject<Item> registerNugget(String name) {
        return ITEMS.register(name, () -> new Item(new Item.Properties()));
    }

    public static void register(IEventBus eventBus) {
        ITEMS.register(eventBus);
    }
}