package org.quiltmc.users.duckteam.ducktech.items;

import net.minecraft.world.item.Item;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class DuckTechItemsRawOreReg {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, org.quiltmc.users.duckteam.ducktech.DuckTech.MODID);

    public static final RegistryObject<Item> RAW_LEAD = registerRawOre("raw_lead");
    public static final RegistryObject<Item> RAW_ALUMINUM = registerRawOre("raw_aluminum");
    public static final RegistryObject<Item> RAW_TIN = registerRawOre("raw_tin");
    public static final RegistryObject<Item> RAW_SILVER = registerRawOre("raw_silver");

    private static RegistryObject<Item> registerRawOre(String name) {
        return ITEMS.register(name, () -> new Item(new Item.Properties()));
    }

    public static void register(IEventBus eventBus) {
        ITEMS.register(eventBus);
    }
}