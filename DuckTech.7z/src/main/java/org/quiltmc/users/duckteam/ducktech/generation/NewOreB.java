package org.quiltmc.users.duckteam.ducktech.generation;

import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.levelgen.VerticalAnchor;
import net.minecraft.world.level.levelgen.placement.*;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;
import org.quiltmc.users.duckteam.ducktech.DuckTech;

import java.util.List;

//Aluminum生成B部分
/*public class NewOreB {
    public static final DeferredRegister<PlacedFeature> PLACED_FEATURES =
            DeferredRegister.create(Registries.PLACED_FEATURE, DuckTech.MODID);
    public static final RegistryObject<PlacedFeature> ALUMINUM_ORE = PLACED_FEATURES.register(
            "aluminum_ore",
            () -> new PlacedFeature(
                    Holder.direct(NewOreA.ALUMINUM_ORE.get()),
                    commonOrePlacement(
                            20,
                            HeightRangePlacement.uniform(
                                    VerticalAnchor.bottom(),
                                    VerticalAnchor.absolute(64)
                            )
                    )
            )
    );

    private static List<PlacementModifier> commonOrePlacement(int countPerChunk, PlacementModifier height) {
        return List.of(
                CountPlacement.of(countPerChunk),
                InSquarePlacement.spread(),
                height,
                BiomeFilter.biome()
        );
    }

    public static void register(IEventBus eventBus) {
        PLACED_FEATURES.register(eventBus);
    }
}*/
//问DeepSeek要的
/*public class ModWorldEvents {
    @SubscribeEvent
    public static void onBiomeLoading(BiomeLoadingEvent event) {
        // 仅在主世界生成
        if (event.getCategory() == Biome.BiomeCategory.NETHER ||
                event.getCategory() == Biome.BiomeCategory.THEEND) {
            return;
        }

        // 直接使用特征引用
        if (ModFeatures.EXAMPLE_ORE_PLACED != null) {
            event.getGeneration().addFeature(
                    GenerationStep.Decoration.UNDERGROUND_ORES,
                    ModFeatures.EXAMPLE_ORE_PLACED.getKey()
            );
        }
    }
}*/
