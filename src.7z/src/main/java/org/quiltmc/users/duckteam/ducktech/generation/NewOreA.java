package org.quiltmc.users.duckteam.ducktech.generation;

import net.minecraft.core.registries.Registries;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.configurations.OreConfiguration;
import net.minecraft.world.level.levelgen.structure.templatesystem.TagMatchTest;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import org.quiltmc.users.duckteam.ducktech.DuckTech;
import org.quiltmc.users.duckteam.ducktech.blocks.DTBlocks;

import java.util.List;
import java.util.function.Supplier;

public class NewOreA {
    public static final DeferredRegister<ConfiguredFeature<?, ?>> CONFIGURED_FEATURES =
            DeferredRegister.create(Registries.CONFIGURED_FEATURE, DuckTech.MODID);

    //aluminum生成A部分
    public static final Supplier<ConfiguredFeature<OreConfiguration, ?>> ALUMINUM_ORE = CONFIGURED_FEATURES.register(
            "aluminum_ore",
            () -> new ConfiguredFeature<>(
                    Feature.ORE,
                    new OreConfiguration(
                            List.of(
                                    OreConfiguration.target(
                                            new TagMatchTest(BlockTags.STONE_ORE_REPLACEABLES), // 在石头中生成
                                            DTBlocks.ALUMINUM_ORE.get().defaultBlockState()
                                    )
                            ),
                            9,
                            0.5f
                    )
            )
    );

    public static void register(IEventBus eventBus) {
        CONFIGURED_FEATURES.register(eventBus);
    }}
    //public class NewOreA {
        //public static void register() {
            // 使用Forge的矿物生成API
            //NewOreA.addOre(
                    //DuckTechBlocksOre.ALUMINUM_ORE.get(),
                    //9, // 矿脉大小
                    //20, // 每个区块生成次数
                    //HeightRange.of(UniformHeight.of(VerticalAnchor.bottom(), VerticalAnchor.absolute(64))),
                    //BiomeTags.IS_OVERWORLD // 在主世界生成
            //);
        //}
    //}
//}