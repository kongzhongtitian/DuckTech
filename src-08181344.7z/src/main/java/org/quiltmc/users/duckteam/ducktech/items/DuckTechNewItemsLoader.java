package org.quiltmc.users.duckteam.ducktech.items;

import net.minecraftforge.eventbus.api.IEventBus;
import org.quiltmc.users.duckteam.ducktech.DuckTech;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class DuckTechNewItemsLoader {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, DuckTech.MODID);

    public static void register(IEventBus eventBus) {
        ITEMS.register(eventBus);
    }
}
