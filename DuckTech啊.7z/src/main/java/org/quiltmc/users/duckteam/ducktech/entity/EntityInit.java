package org.quiltmc.users.duckteam.ducktech.entity;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class EntityInit {
    // 创建 DeferredRegister 用于实体类型
    //public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, "ducktech");

    // 注册实体类型
    //public static final DeferredRegister<EntityType<?>> ENTITIES =
    //        DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, "ducktech");

    //public static final RegistryObject<EntityType<RubberDuckEntity>> RUBBER_DUCK =
    //        ENTITIES.register("rubber_duck",
    //                () -> EntityType.Builder.of(RubberDuckEntity::new, MobCategory.CREATURE)
    //                        .sized(0.6f, 0.8f)
    //                        .build("rubber_duck"));

    // 记得在你的主模组类的构造函数中调用 ENTITIES.register(FMLJavaModLoadingContext.get().getModEventBus());
}
