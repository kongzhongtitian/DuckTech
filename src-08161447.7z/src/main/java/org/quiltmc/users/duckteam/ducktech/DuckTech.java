package org.quiltmc.users.duckteam.ducktech;

import org.quiltmc.users.duckteam.ducktech.blocks.*;
import org.quiltmc.users.duckteam.ducktech.items.*;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;


@Mod(DuckTech.MODID)
public class DuckTech {
    public static final String MODID = "ducktech";

    public DuckTech(FMLJavaModLoadingContext context)
    {
        IEventBus modEventBus = context.getModEventBus();

        DTBlockEntity.BLOCK_ENTITY_TYPES.register(modEventBus);
        DTBlocks.BLOCKS.register(modEventBus);
        //DTItems.ITEMS.register(modEventBus);
        DTCreativeTab.CREATIVE_TABS.register(modEventBus);
        DuckTechItemsNuggetRegister.register(modEventBus);
        DuckTechItemsLoader.register(modEventBus);
        DuckTechItemsRawOreReg.register(modEventBus);
        DuckTechBlocksMetal.register(modEventBus);
        DuckTechBlocksOre.register(modEventBus);
        DuckTechBlocksRawOre.register(modEventBus);
        DuckTechNewItemsLoader.ITEMS.register(modEventBus);
    }
}
