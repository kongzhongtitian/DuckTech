package org.quiltmc.users.duckteam.ducktech.items;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import org.quiltmc.users.duckteam.ducktech.DuckTech;
import org.quiltmc.users.duckteam.ducktech.blocks.DuckTechBlocksMetal;
import java.util.function.Supplier;

public class DTCreativeTab {
    public static final RegistryObject<CreativeModeTab> DUCKTECH_TAB = CREATIVE_MOD_TAB.register("ducktech_tab", () -> CreativeModeTab.builder()
            // Set name of tab to display
            .title(Component.translatable("item_group." + DuckTech.MODID + ".example"))
            // Set icon of creative tab
            .icon(Items.GOLDEN_APPLE::getDefaultInstance)
            // Add default items to tab
            .displayItems((params, output) -> {
                for (RegistryObject<Item> entry : DTItems.ITEMS.getEntries()) {
                    if(entry.isPresent())output.accept(entry.get().getDefaultInstance());
                }
                for (RegistryObject<Item> entry : DuckTechItemsLoader.ITEMS.getEntries()) {
                    if(entry.isPresent())output.accept(entry.get().getDefaultInstance());
                }
                for (RegistryObject<Item> entry : DuckTechItemsRawOreReg.ITEMS.getEntries()) {
                    if(entry.isPresent())output.accept(entry.get().getDefaultInstance());
                }
                for (RegistryObject<Item> entry : DuckTechItemsNuggetRegister.ITEMS.getEntries()) {
                    if(entry.isPresent())output.accept(entry.get().getDefaultInstance());
                }
            })
            .build()
    );
}
