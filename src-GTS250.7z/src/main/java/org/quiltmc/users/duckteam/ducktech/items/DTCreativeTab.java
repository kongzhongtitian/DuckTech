package org.quiltmc.users.duckteam.ducktech.items;

import org.quiltmc.users.duckteam.ducktech.DuckTech;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Items;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class DTCreativeTab {
    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, DuckTech.MODID);

    static String MOD_NAME_STRING = "creative.ducktech_tab";

    public static final RegistryObject<CreativeModeTab> DUCKTECH_TAB = CREATIVE_MODE_TABS.register("ducktech_tab", () -> CreativeModeTab.builder()
            // Set name of tab to display
            .title(Component.translatable("item_group." + DuckTech.MODID + ".example"))
            // Set icon of creative tab
            .icon(() -> Items.GOLDEN_APPLE.getDefaultInstance())
            // Add default items to tab
            .displayItems((params, output) -> {

            })
            .build()
    );
}