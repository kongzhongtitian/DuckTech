package org.quiltmc.users.duckteam.ducktech.blocks;

import org.quiltmc.users.duckteam.ducktech.DuckTech;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;

public class DTBlockEntity {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITY_TYPES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, DuckTech.MODID);
}
